<div class="error">	
<div class="container">
<h1 class="text-center">Ошибка 404</h1>
<p>Файл отсутствует.</p>
</div>
</div>