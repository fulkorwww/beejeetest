<div class="error">	
<div class="container">
<h1 class="text-center">Ошибка 500</h1>
<p>Внутренняя ошибка сервера.</p>
</div>
</div>