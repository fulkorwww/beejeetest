<?php

return [
'type' => 'mysql',
'host' => 'localhost',
'dbname' => 'beejeetest',
'charset' => 'utf8',
'user' => 'test',
'pass' => '123'
];

?>