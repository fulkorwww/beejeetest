<?php

namespace Controllers;

class Login extends \App\Controller
{
    public function index()
    {
	return $this->render('Login');
    }
}

?>