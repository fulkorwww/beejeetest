<?php

namespace Controllers;

class Newtask extends \App\Controller
{
    public function index()
    {
	return $this->render('Newtask');
    }
}

?>